from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from app.routes.api import router
from app.models import make_migration

app = FastAPI()
app.mount("/images", StaticFiles(directory="app/templates/src/images"), name="images")
migration = make_migration()

app.include_router(router)