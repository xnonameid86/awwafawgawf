from pydantic import BaseModel, PositiveInt, NonPositiveInt

class AddPendaftaran(BaseModel):
  kdProviderPeserta: str
  tglDaftar: str
  noKartu: str
  kdPoli: str
  keluhan: str
  kunjSakit: bool
  sistole: NonPositiveInt | PositiveInt
  diastole: NonPositiveInt | PositiveInt
  beratBadan: NonPositiveInt | PositiveInt
  tinggiBadan: NonPositiveInt | PositiveInt
  respRate: NonPositiveInt | PositiveInt
  lingkarPerut: NonPositiveInt | PositiveInt
  heartRate: NonPositiveInt | PositiveInt
  rujukBalik: NonPositiveInt | PositiveInt
  kdTkp: int

