from pydantic import BaseModel, validator

class CreateAntrean(BaseModel):
  nomorkartu: str
  nik: str
  kodepoli: str
  tanggalperiksa: str
  keluhan: str

  @validator('nomorkartu')
  def nomorkartu_validator(cls, value):
    if not value:
      raise ValueError('The nomorkartu is required')
    return value
  
  @validator('nik')
  def nik_validator(cls, value):
    if not value:
      raise ValueError('The nik is required')
    return value
  
  @validator('kodepoli')
  def kodepoli_validator(cls, value):
    if not value:
      raise ValueError('The kodepoli is required')
    return value
  
  @validator('tanggalperiksa')
  def tanggalperiksa_validator(cls, value):
    if not value:
      raise ValueError('The tanggalperiksa is required')
    return value
  
  @validator('keluhan')
  def keluhan_validator(cls, value):
    if not value:
      raise ValueError('The keluhan is required')
    return value
  
class BatalAntrean(BaseModel):
  nomorkartu: str
  kodepoli: str
  tanggalperiksa: str

  @validator('nomorkartu')
  def nomorkartu_validator(cls, value):
    if not value:
      raise ValueError('The nomorkartu is required')
    return value
  
  @validator('kodepoli')
  def kodepoli_validator(cls, value):
    if not value:
      raise ValueError('The kodepoli is required')
    return value
  
  @validator('tanggalperiksa')
  def tanggalperiksa_validator(cls, value):
    if not value:
      raise ValueError('The tanggalperiksa is required')
    return value

class CreatePasien(BaseModel):
  nomorkartu: str
  nik: str
  nomorkk: str
  nama: str
  jeniskelamin: str
  tanggallahir: str
  alamat: str
  kodeprop: str
  namaprop: str
  kodedati2: str
  namadati2: str
  kodekec: str
  namakec: str
  kodekel: str
  namakel: str
  rw: str
  rt: str

  @validator('nomorkartu')
  def nomorkartu_validator(cls, value):
    if not value:
      raise ValueError('The nomorkartu is required')
    return value
  
  @validator('nik')
  def nik_validator(cls, value):
    if not value:
      raise ValueError('The nik is required')
    return value
  
  @validator('nomorkk')
  def nomorkk_validator(cls, value):
    if not value:
      raise ValueError('The nomorkk is required')
    return value
  
  @validator('nama')
  def nama_validator(cls, value):
    if not value:
      raise ValueError('The nama is required')
    return value
  
  @validator('jeniskelamin')
  def jeniskelamin_validator(cls, value):
    if not value:
      raise ValueError('The jeniskelamin is required')
    return value
  
  @validator('tanggallahir')
  def tanggallahir_validator(cls, value):
    if not value:
      raise ValueError('The tanggallahir is required')
    return value
  
  @validator('alamat')
  def alamat_validator(cls, value):
    if not value:
      raise ValueError('The alamat is required')
    return value
  
  @validator('kodeprop')
  def kodeprop_validator(cls, value):
    if not value:
      raise ValueError('The kodeprop is required')
    return value
  
  @validator('namaprop')
  def namaprop_validator(cls, value):
    if not value:
      raise ValueError('The namaprop is required')
    return value
  
  @validator('kodedati2')
  def kodedati2_validator(cls, value):
    if not value:
      raise ValueError('The kodedati2 is required')
    return value
  
  @validator('namadati2')
  def namadati2_validator(cls, value):
    if not value:
      raise ValueError('The namadati2 is required')
    return value
  
  @validator('kodekec')
  def kodekec_validator(cls, value):
    if not value:
      raise ValueError('The kodekec is required')
    return value
  
  @validator('namakec')
  def namakec_validator(cls, value):
    if not value:
      raise ValueError('The namakec is required')
    return value
  
  @validator('kodekel')
  def kodekel_validator(cls, value):
    if not value:
      raise ValueError('The kodekel is required')
    return value
  
  @validator('namakel')
  def namakel_validator(cls, value):
    if not value:
      raise ValueError('The namakel is required')
    return value
  
  @validator('rw')
  def rw_validator(cls, value):
    if not value:
      raise ValueError('The rw is required')
    return value
  
  @validator('rt')
  def rt_validator(cls, value):
    if not value:
      raise ValueError('The rt is required')
    return value