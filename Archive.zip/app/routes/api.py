from fastapi import APIRouter, Header, Response, status, Depends, Request
from app.database.database import SessionLocal
from typing import Annotated
from sqlalchemy.orm import Session

from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.controllers.auth import AuthController
from app.controllers.antrean import AntreanController
from app.controllers.pasien import PasienController

from app.schemas.schema import CreateAntrean
from app.schemas.schema import BatalAntrean
from app.schemas.schema import CreatePasien

router = APIRouter()

def get_db():
  db = SessionLocal()
  try:
    yield db
  finally:
    db.close()

db_dependency = Annotated[Session, Depends(get_db)]

templates = Jinja2Templates(directory="app/templates")

@router.get('/', response_class=HTMLResponse)
async def root_path(request: Request):
  return templates.TemplateResponse(
        request=request, name="index.html"
    )

@router.get('/auth')
async def authentication(response: Response, x_username: str = Header(), x_password: str = Header()):
  auth = AuthController().login(x_username, x_password)
  response.status_code = auth['metadata']['code']
  return auth

@router.post('/antrean')
async def create_antrean(response: Response, db: db_dependency, antreans: CreateAntrean, x_token: str = Header(), x_username: str = Header()):
  auth = AuthController().login_by_token(x_token, x_username)
  if not auth:
    response.status_code = status.HTTP_401_UNAUTHORIZED
    return {
      "metadata": {
        "message": "Token is Invalid or Token is Expired",
        "code": status.HTTP_401_UNAUTHORIZED
      }
    }
  
  created = AntreanController().create_antrean(antreans, db)
  response.status_code = created['metadata']['code']
  return created

@router.get('/antrean/status/{kodepoli}/{tanggalperiksa}')
async def status_antrean(response: Response, db: db_dependency, kodepoli: str, tanggalperiksa: str, x_token: str = Header(), x_username: str = Header()):
  auth = AuthController().login_by_token(x_token, x_username)
  if not auth:
    response.status_code = status.HTTP_401_UNAUTHORIZED
    return {
      "metadata": {
        "message": "Token is Invalid or Token is Expired",
        "code": status.HTTP_401_UNAUTHORIZED
      }
    }
  
  status = AntreanController().status_antrean(kodepoli, tanggalperiksa, db)
  response.status_code = status['metadata']['code']
  return status

@router.get("/antrean/sisapeserta/{nomorkartu_jkn}/{kodepoli}/{tanggalperiksa}")
async def sisa_antrean(response: Response, db: db_dependency, nomorkartu_jkn: str, kodepoli: str, tanggalperiksa: str, x_token: str = Header(), x_username: str = Header()):
  auth = AuthController().login_by_token(x_token, x_username)
  if not auth:
    response.status_code = status.HTTP_401_UNAUTHORIZED
    return {
      "metadata": {
        "message": "Token is Invalid or Token is Expired",
        "code": status.HTTP_401_UNAUTHORIZED
      }
    }
  
  sisaantrean = AntreanController().sisa_antrean(nomorkartu_jkn, kodepoli, tanggalperiksa, db)
  response.status_code = sisaantrean['metadata']['code']
  return sisaantrean

@router.put("/antrean/batal")
async def batal_antrean(response: Response, db: db_dependency, antrean: BatalAntrean, x_token: str = Header(), x_username: str = Header()):
  auth = AuthController().login_by_token(x_token, x_username)
  if not auth:
    response.status_code = status.HTTP_401_UNAUTHORIZED
    return {
      "metadata": {
        "message": "Token is Invalid or Token is Expired",
        "code": status.HTTP_401_UNAUTHORIZED
      }
    }
  
  batalantrean = AntreanController().batal_antrean(db, antrean)
  response.status_code = batalantrean['metadata']['code']
  return batalantrean

@router.post("/peserta")
async def create_pasien(response: Response, db : db_dependency, pasien: CreatePasien, x_token: str = Header(), x_username: str = Header()):
  auth = AuthController().login_by_token(x_token, x_username)
  if not auth:
    response.status_code = status.HTTP_401_UNAUTHORIZED
    return {
      "metadata": {
        "message": "Token is Invalid or Token is Expired",
        "code": status.HTTP_401_UNAUTHORIZED
      }
    }
  
  createpatient = PasienController().create_pasien(pasien, db)
  response.status_code = createpatient['metadata']['code']
  return createpatient