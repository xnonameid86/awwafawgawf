from fastapi import APIRouter

from app.controllers.poli import PoliController
from app.controllers.pendaftaran import PendaftaranController
from app.controllers.peserta import PesertaController

from app.schemas.schema import AddPendaftaran

router = APIRouter()

@router.get("/")
async def root_path():
  return {"status":"API was running ..."}

@router.get('/pcare/poli/fktp/{param_1}/{param_2}')
async def get_poli_fktp(param_1: int, param_2: int):
  get_poli = PoliController().get_poli(param_1, param_2)
  return get_poli

@router.post('/pendaftaran')
async def add_data_pendaftaran(data: AddPendaftaran):
  data = data.model_dump_json()
  add_pendaftaran = PendaftaranController().add_pendaftaran(data)

  return add_pendaftaran

@router.get('/pendaftaran/noUrut/{noUrut}/tglDaftar/{tglDaftar}')
async def get_data_pendaftaran(noUrut: str, tglDaftar: str):
  get_pendaftaran = PendaftaranController().get_pendaftaran_by_nomor_urut(noUrut, tglDaftar)

  return get_pendaftaran

@router.delete('/pendaftaran/peserta/{nokartu}/tglDaftar/{tglDaftar}/noUrut/{noUrut}/kdPoli/{kdPoli}')
async def delete_data_peserta(nokartu: str, tglDaftar: str, noUrut: str, kdPoli: str):
  delete_pendaftaran = PendaftaranController().delete_pendaftaran(nokartu, tglDaftar, noUrut, kdPoli)

  return delete_pendaftaran

@router.get('/peserta/{nokartu}')
async def get_data_peserta(nokartu: str):
  get_peserta = PesertaController().get_peserta(nokartu)
  
  return get_peserta

@router.get('/peserta/{jeniskartu}/{nokartu}')
async def get_data_peserta_by_jeniskartu(nokartu: str, jeniskartu: str):
  get_peserta = PesertaController().get_peserta_by_jenis_kartu(jeniskartu, nokartu)

  return get_peserta