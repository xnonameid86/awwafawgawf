from fastapi import APIRouter, Request

from app.controllers.poli import PoliController
from app.controllers.pendaftaran import PendaftaranController

from app.schemas.schema import AddPendaftaran

router = APIRouter()

@router.get('/pcare/poli/fktp/{param_1}/{param_2}')
async def get_poli_fktp(param_1: int, param_2: int):
  get_poli = PoliController().get_poli()
  return get_poli

@router.post('/pendaftaran')
async def add_data_pendaftaran(data: AddPendaftaran):
  data = data.model_dump_json()
  add_pendaftaran = PendaftaranController().add_pendaftaran(data)

  return add_pendaftaran
