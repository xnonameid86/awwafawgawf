from app.database.database import engine

from . import antrean, pasien

def make_migration():
  antrean.Base.metadata.create_all(bind=engine)
  pasien.Base.metadata.create_all(bind=engine)