from sqlalchemy import Column, Integer, String, DateTime, TIMESTAMP, text
from app.database.database import Base
from dotenv import load_dotenv
from os import getenv
from datetime import datetime
from pytz import timezone

class Antreans(Base):
  __tablename__ = getenv('ANTREAN')

  id = Column(Integer, primary_key=True, index=True)
  antrean = Column(String, nullable=False)
  state = Column(String, default="draft")
  nomorkartu = Column(String, nullable=False)
  nik = Column(String, nullable=False)
  kodepoli = Column(String, nullable=False)
  tanggalperiksa = Column(String, nullable=False)
  keluhan = Column(String, nullable=False)
  created_at = Column(TIMESTAMP(timezone=False), default=datetime.now(timezone('UTC')).astimezone(timezone('Asia/Jakarta')).strftime("%Y-%m-%d %H:%M:%S.%f"), server_default=text('Now()'))
  updated_at = Column(DateTime)