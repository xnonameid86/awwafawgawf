from sqlalchemy import Column, Integer, String, DateTime, text, TIMESTAMP
from sqlalchemy.orm import validates
from app.database.database import Base
from dotenv import load_dotenv
from os import getenv
from datetime import datetime
from pytz import timezone

class Pasien(Base):
  __tablename__ = getenv('PASIEN')

  id = Column(Integer, primary_key=True, index=True)
  nomorkartu = Column(String, nullable=False)
  nik = Column(String, nullable=False)
  nomorkk = Column(String, nullable=False)
  nama = Column(String, nullable=False)
  jeniskelamin = Column(String, nullable=False)
  tanggallahir = Column(String, nullable=False)
  alamat = Column(String, nullable=False)
  kodeprop = Column(String, nullable=False)
  namaprop = Column(String, nullable=False)
  kodedati2 = Column(String, nullable=False)
  namadati2 = Column(String, nullable=False)
  kodekec = Column(String, nullable=False)
  namakec = Column(String, nullable=False)
  kodekel = Column(String, nullable=False)
  namakel = Column(String, nullable=False)
  rw = Column(String, nullable=False)
  rt = Column(String, nullable=False)
  created_at = Column(TIMESTAMP(timezone=False), default=datetime.now(timezone('UTC')).astimezone(timezone('Asia/Jakarta')).strftime("%Y-%m-%d %H:%M:%S.%f"), server_default=text('Now()'))
  updated_at = Column(DateTime)

  @validates('nama')
  def convert_upper(self, key, value):
    return value.upper()