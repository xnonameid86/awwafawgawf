from app.models.antrean import Antreans
from fastapi import status

class AntreanController:
  
  def __init__(self) -> None:
    pass

  def check_poli(self, kodepoli):
    polis = [
      ["001", "UMUM"],
      ["002", "GIGI"],
      ["003", "KIA"]
    ]

    for poli in polis:
      if poli[0] == kodepoli:
        return poli[1]

  def create_antrean(self, antreans, db):
    try:
      is_exist = db.query(Antreans).filter(Antreans.nomorkartu == antreans.nomorkartu, Antreans.tanggalperiksa == antreans.tanggalperiksa, Antreans.kodepoli == antreans.kodepoli).first()

      poli_name = self.check_poli(antreans.kodepoli)
      
      if is_exist:
        return {
          "metadata": {
            "message": "Nomor kartu {} telah terdaftar antrean tanggal {} di Poli {}".format(antreans.nomorkartu, antreans.tanggalperiksa, poli_name),
            "code": status.HTTP_201_CREATED
          }
        }

      list_antrean = db.query(Antreans.antrean).filter(Antreans.tanggalperiksa == antreans.tanggalperiksa, Antreans.kodepoli == antreans.kodepoli).all()

      if len(list_antrean) == 0:
        nomor_antrean = "{:03n}".format(1)
        db_antrean = Antreans(antrean=nomor_antrean, **antreans.dict())
        db.add(db_antrean)
        db.commit()
        db.refresh(db_antrean)
      else:
        nomor_antrean = "{:03n}".format(int(max(list_antrean)[0]) + 1)
        db_antrean = Antreans(antrean=nomor_antrean, **antreans.dict())
        db.add(db_antrean)
        db.commit()
        db.refresh(db_antrean)

      sisaantrean = db.query(Antreans.antrean).filter(Antreans.tanggalperiksa == antreans.tanggalperiksa, Antreans.kodepoli == antreans.kodepoli, Antreans.state == 'draft').all()
      filter_antreanpanggil = db.query(Antreans.antrean).filter(Antreans.tanggalperiksa == antreans.tanggalperiksa, Antreans.kodepoli == antreans.kodepoli, Antreans.state == 'pelayanan').first()

      if not filter_antreanpanggil:
        antreanpanggil = ""
      else:
        antreanpanggil = "A{}".format(filter_antreanpanggil[0])
    
      return {
        "response": {
          "nomorantrean": "A{}".format(nomor_antrean),
          "angkaantrean": "{}".format(int(nomor_antrean)),
          "namapoli": "Poli {}".format(poli_name),
          "sisaantrean": "{}".format(len(sisaantrean)),
          "antreanpanggil": antreanpanggil,
          "keterangan": "Apabila antrean terlewat harap mengambil antrean kembali."
        },
        "metadata": {
          "message": "Ok",
          "code": status.HTTP_200_OK
        }
      }

    except Exception as err:
      return {
        "metadata": {
          "message": err,
          "code": status.HTTP_500_INTERNAL_SERVER_ERROR
        }
      }

  def status_antrean(self, kodepoli, tanggalperiksa, db):
    try:
      antreans = db.query(Antreans).filter(Antreans.kodepoli == kodepoli, Antreans.tanggalperiksa == tanggalperiksa).all()

      poli_name = self.check_poli(kodepoli)
      
      if not antreans:
        return {
          "metadata": {
            "message": "Data antrean Poli {} tanggal {} not found".format(poli_name, tanggalperiksa),
            "code": status.HTTP_201_CREATED
          }
        }
      
      sisaantrean = db.query(Antreans).filter(Antreans.kodepoli == kodepoli, Antreans.tanggalperiksa == tanggalperiksa, Antreans.state == 'draft').all()
      filter_antreanpanggil = db.query(Antreans.antrean).filter(Antreans.kodepoli == kodepoli, Antreans.tanggalperiksa == tanggalperiksa, Antreans.state == 'pelayanan').first()

      if not filter_antreanpanggil:
        antreanpanggil = ""
      else:
        antreanpanggil = "A{}".format(filter_antreanpanggil[0])

      return {
        "response": {
          "namapoli": "Poli {}".format(poli_name),
          "totalantrean": "{}".format(len(antreans)),
          "sisaantrean": "{}".format(len(sisaantrean)),
          "antreanpanggil": antreanpanggil,
          "keterangan": ""
        },
        "metadata": {
          "message": "Ok",
          "code": status.HTTP_200_OK
        }
      }

    except Exception as err:
      return {
        "metadata": {
          "message": err,
          "code": status.HTTP_201_CREATED
        }
      }

  def sisa_antrean(self, nomorkartu_jkn, kodepoli, tanggalperiksa, db):
    try:
      antrean = db.query(Antreans).filter(Antreans.kodepoli == kodepoli, Antreans.tanggalperiksa == tanggalperiksa, Antreans.nomorkartu == nomorkartu_jkn).first()

      poli_name = self.check_poli(kodepoli)

      if not antrean:
        return {
          "metadata": {
            "message": "Data antrean Poli {} tanggal {} not found".format(poli_name, tanggalperiksa),
            "code": status.HTTP_201_CREATED
          }
        }
      
      sisaantrean = db.query(Antreans).filter(Antreans.kodepoli == kodepoli, Antreans.tanggalperiksa == tanggalperiksa, Antreans.state == 'draft').all()
      filter_antreanpanggil = db.query(Antreans.antrean).filter(Antreans.kodepoli == kodepoli, Antreans.tanggalperiksa == tanggalperiksa, Antreans.state == 'pelayanan').first()

      if not filter_antreanpanggil:
        antreanpanggil = ""
      else:
        antreanpanggil = "A{}".format(filter_antreanpanggil[0])

      return {
        "response": {
          "nomorantrean": "A{}".format(antrean.antrean),
          "namapoli": "Poli {}".format(poli_name),
          "sisaantrean": "{}".format(len(sisaantrean)),
          "antreanpanggil": antreanpanggil,
          "keterangan": ""
        },
        "metadata": {
          "message": "Ok",
          "code": status.HTTP_200_OK
        }
      }
    
    except Exception as err:
      return {
        "metadata": {
          "message": err,
          "code": status.HTTP_201_CREATED
        }
      }

  def batal_antrean(self, db, antrean):
    try:
      is_exist = db.query(Antreans).filter(Antreans.nomorkartu == antrean.nomorkartu, Antreans.kodepoli == antrean.kodepoli, Antreans.tanggalperiksa == antrean.tanggalperiksa)

      poli_name = self.check_poli(antrean.kodepoli)

      if not is_exist.first():
        return {
          "metadata": {
            "message": "Antrean dengan nomor kartu {} pada tanggal {} di Poli {} tidak ditemukan".format(antrean.nomorkartu, antrean.tanggalperiksa, poli_name),
            "code": status.HTTP_201_CREATED
          }
        }
      
      is_exist.update({'state': 'batal'})
      db.commit()

      return {
        "metadata": {
          "code": status.HTTP_200_OK,
          "message": "OK"
        }
      }
      
    except Exception as err:
      return {
        "metadata": {
          "message": err,
          "code": status.HTTP_201_CREATED
        }
      }