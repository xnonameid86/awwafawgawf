from dotenv import load_dotenv
from os import getenv
from app.utils.encryption import fernet
from fastapi import status
from datetime import timedelta, datetime
from pytz import timezone
from jose import jwt, JWTError

class AuthController:

  def __init__(self) -> None:
    self.SECRET_KEY = getenv('SECRET_KEY')
    self.ALGORITHM = getenv('ALGORITHM')

  def login(self, x_username, x_password):
    try:
      USER_ID = getenv('USER_ID')
      USERNAME = getenv('USERNAME')
      PASSWORD = getenv('PASSWORD')

      if x_username != USERNAME:
        return {
          "metadata": {
            "message": "Username or password is wrong",
            "code": status.HTTP_401_UNAUTHORIZED
          }
        }
      
      decode_password = fernet.decrypt(PASSWORD).decode('utf-8')
      if x_password != decode_password:
        return {
          "metadata": {
            "message": "Username or password is wrong",
            "code": status.HTTP_401_UNAUTHORIZED
          }
        }
      
      token = self.create_token(x_username, USER_ID, timedelta(minutes=60))
      return {
        "response": {
          "token": token
        },
        "metadata": {
          "message": "Ok",
          "code": status.HTTP_200_OK
        }
      }

    except Exception as err:
      return {"error": err}

  def create_token(self, username, user_id, expires_delta):
    encode = {"sub": username, "id": user_id}
    expires = datetime.now(timezone("Asia/Jakarta")) + expires_delta
    encode.update({'exp': expires})

    return jwt.encode(encode, self.SECRET_KEY, algorithm=self.ALGORITHM)
  
  def login_by_token(self, x_token, x_username):
    try:
      payload = jwt.decode(x_token, self.SECRET_KEY, algorithms=self.ALGORITHM)
      username = payload.get('sub')
      user_id = payload.get('id')

      if username is None or user_id is None:
        return False
      
      return True
    except JWTError:
      return False