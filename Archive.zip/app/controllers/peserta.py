import requests, json
from app.utils.headers import header
from app.utils.decrypt import decrypt

from os import getenv
from dotenv import load_dotenv

load_dotenv()

class PesertaController:

  def get_peserta(self, nokartu):
    try:

      base_url = getenv('BASE_URL')
      result = requests.get(f"{base_url}/peserta/{nokartu}", headers=header).text

      try:
        json_data = json.loads(result)
        if json_data['metaData']['message'] != "OK":
          return json_data
        
        response_encrypt = json_data['response']
        response_decrypt = decrypt(header, response_encrypt)
        json_data['response'] = response_decrypt

        return json_data
      except ValueError as val:
        return {"error":val}

    except Exception as err:
      return {"error":err}

  def get_peserta_by_jenis_kartu(self, jeniskartu, nokartu):
    try:
      base_url = getenv('BASE_URL')
      result = requests.get(f"{base_url}/peserta/{jeniskartu}/{nokartu}", headers=header).text

      try:
        json_data = json.loads(result)
        if json_data['metaData']['message'] != "OK":
          return result
        
        response_encrypt = json_data['response']
        response_decrypt = decrypt(header, response_encrypt)
        json_data['response'] = response_decrypt

        return json_data
      except:
        return {"error":result}
      
    except Exception as err:
      return {"error":err}