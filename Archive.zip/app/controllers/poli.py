import requests, json
from app.utils.headers import header
from app.utils.decrypt import decrypt

from os import getenv
from dotenv import load_dotenv

load_dotenv()

class PoliController:

  def get_poli(self, param_1, param_2):
    base_url = getenv('BASE_URL')
    result = requests.get(f"{base_url}/poli/fktp/{param_1}/{param_2}", headers=header).text

    if 'response' not in result:
      return
    
    json_data = json.loads(result)
    response_encrypt = json_data['response']
    response_decrypt = decrypt(header, response_encrypt)

    return response_decrypt