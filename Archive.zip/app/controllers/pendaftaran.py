import requests, json
from app.utils.headers import header
from app.utils.decrypt import decrypt

from os import getenv
from dotenv import load_dotenv

load_dotenv()

class PendaftaranController:

  def add_pendaftaran(self, data):
    try:
      base_url = getenv('BASE_URL')
      result = requests.post(f"{base_url}/pendaftaran", headers=header, data=data).text

      try:
        json_data = json.loads(result)
        response_encrypt = json_data['response']
        response_decrypt = decrypt(header, response_encrypt)
        json_data['response'] = response_decrypt
        
        return json_data
      except:
        return {"error": result}

    except Exception as err:
      return {"error": err}
  
  def get_pendaftaran_by_nomor_urut(self, noUrut, tglDaftar):
    try:
      base_url = getenv('BASE_URL')
      result = requests.get(f"{base_url}/pendaftaran/noUrut/{noUrut}/tglDaftar/{tglDaftar}", headers=header).text

      try:
        json_data = json.loads(result)
        response_encrypt = json_data['response']
        response_decrypt = decrypt(header, response_encrypt)
        json_data['response'] = response_decrypt
        return json_data
      except:
        return {"error": result}

    except Exception as err:
      return {"error": err}
  
  def delete_pendaftaran(self, nokartu, tglDaftar, noUrut, kdPoli):
    try:
      base_url = getenv('BASE_URL')
      result = requests.delete(f"{base_url}/pendaftaran/peserta/{nokartu}/tglDaftar/{tglDaftar}/noUrut/{noUrut}/kdPoli/{kdPoli}", headers=header).text

      try:
        json_data = json.loads(result)
        return json_data
      except:
        return {"error": result}

    except Exception as err:
      return {"error": err}