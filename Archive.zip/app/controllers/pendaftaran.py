import requests, json
from app.utils.headers import header
from app.utils.decrypt import decrypt

from os import getenv
from dotenv import load_dotenv

load_dotenv()

class PendaftaranController:

  def add_pendaftaran(self, data):
    base_url = getenv('BASE_URL')
    result = requests.post(f"{base_url}/pendaftaran", headers=header, data=data).text
    json_data = json.loads(result)
    response_encrypt = json_data['response']
    response_decrypt = decrypt(header, response_encrypt)
    
    return response_decrypt