from app.models.pasien import Pasien
from fastapi import status

class PasienController:

  def __init__(self) -> None:
    pass

  def create_pasien(self, pasien, db):
    try:
      is_exist = db.query(Pasien).filter(Pasien.nomorkartu == pasien.nomorkartu, Pasien.nik == pasien.nik, Pasien.nomorkk == pasien.nomorkk)

      if is_exist.first():
        return {
          "metadata": {
            "message": "Pasien dengan data tersebut sudah ada",
            "code": status.HTTP_201_CREATED
          }
        }
      
      db_pasien = Pasien(**pasien.dict())
      db.add(db_pasien)
      db.commit()
      db.refresh(db_pasien)

      return {
        "metadata": {
          "message": "Ok",
          "code": status.HTTP_200_OK
        }
      }

    except Exception as err:
      return {
        "metadata": {
          "message": err,
          "code": status.HTTP_201_CREATED
        }
      }