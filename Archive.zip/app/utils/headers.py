from .authorization import create_authorization
from .signature import create_signature
from .timestamp import current_timestamp

from os import getenv
from dotenv import load_dotenv

load_dotenv()

cons_id = getenv('X-CONS-ID')
user_key = getenv('USER-KEY')

header = {
  "X-cons-id": "{}".format(cons_id),
  "X-timestamp": "{}".format(current_timestamp()),
  "X-signature": "{}".format(create_signature()),
  "X-authorization": "base64 {}".format(create_authorization()),
  "user_key": "{}".format(user_key)
}