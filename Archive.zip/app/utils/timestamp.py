from datetime import datetime
from pytz import timezone

def current_timestamp():
  current_datetime = datetime.now(timezone('Asia/Jakarta'))
  timestamp = int(round(current_datetime.timestamp()))

  return timestamp
