import base64
from os import getenv
from dotenv import load_dotenv

load_dotenv()

def create_authorization():
  username = getenv('USERNAME_PCARE')
  password = getenv('PASSWORD_PCARE')
  kodeaplikasi = getenv('KODEAPLIKASI')

  string = f"{username}:{password}:{kodeaplikasi}"
  string_bytes = string.encode('utf-8')

  base64_bytes = base64.b64encode(string_bytes) 
  base64_string = base64_bytes.decode("utf-8") 
  
  return base64_string