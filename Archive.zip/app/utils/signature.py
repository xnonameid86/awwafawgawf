import hashlib
import base64
import hmac
from os import getenv
from dotenv import load_dotenv
from .timestamp import current_timestamp

load_dotenv()

def create_signature():

  data = "{}&{}".format(getenv('X-CONS-ID'), current_timestamp()).encode('utf-8') # Mengubah string ke byte object
  secretkey = getenv('SECRET-KEY').encode('utf-8')  # Mengubah string ke byte object

  signature = hmac.new(secretkey, msg=data, digestmod=hashlib.sha256).digest()

  # Base64 encoding
  encodedSignature = base64.b64encode(signature).decode('utf-8') # Example : TB0gNdeRYuq38Puaz+GBeH3ss0sYe96WOXTRxq4cNgY=

  return encodedSignature