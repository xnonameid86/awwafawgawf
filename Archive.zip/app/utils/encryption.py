import base64, hashlib
from cryptography.fernet import Fernet
from dotenv import load_dotenv
from os import getenv

load_dotenv()

def gen_fernet_key(passcode:bytes) -> bytes:
  assert isinstance(passcode, bytes)
  hlib = hashlib.md5()
  hlib.update(passcode)
  return base64.urlsafe_b64encode(hlib.hexdigest().encode('latin-1'))

SECRET_KEY = getenv('SECRET_KEY')
key = gen_fernet_key(SECRET_KEY.encode('utf-8'))
fernet = Fernet(key)