import hashlib, base64, lzstring, json
from Crypto.Cipher import AES

from os import getenv
from dotenv import load_dotenv

load_dotenv()

def decrypt(header, response_encrypt):

    key = "{}{}{}".format(header['X-cons-id'], getenv('SECRET-KEY'), header['X-timestamp'])

    x = lzstring.LZString()

    key_hash = hashlib.sha256(key.encode('utf-8')).digest()

    mode = AES.MODE_CBC

    # decrypt
    decryptor = AES.new(key_hash[0:32], mode, IV=key_hash[0:16])
    plain = decryptor.decrypt(base64.b64decode(response_encrypt))
    decompress = json.loads(x.decompressFromEncodedURIComponent(plain.decode('utf-8')))
    return decompress